clear;
x = 9*9/2